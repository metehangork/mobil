const sqlite3 = require('sqlite3').verbose();
const path = require('path');

// SQLite veritabanı dosyası
const dbPath = path.join(__dirname, '../../database/unicampus.db');

// SQLite bağlantısı oluştur
const db = new sqlite3.Database(dbPath, (err) => {
  if (err) {
    console.error('❌ SQLite bağlantı hatası:', err.message);
  } else {
    console.log('✅ SQLite: bağlantı kuruldu (' + dbPath + ')');
  }
});

// PostgreSQL pool.query() benzeri bir wrapper
async function query(text, params = []) {
  const start = Date.now();
  
  return new Promise((resolve, reject) => {
    // PostgreSQL $1, $2 formatını SQLite ? formatına çevir
    const sqliteQuery = text.replace(/\$(\d+)/g, '?');
    
    if (sqliteQuery.toLowerCase().startsWith('select')) {
      db.all(sqliteQuery, params, (err, rows) => {
        const duration = Date.now() - start;
        if (err) {
          console.error('SQL Hatası:', {
            text: sqliteQuery,
            params,
            message: err.message,
            code: err.code
          });
          reject(err);
        } else {
          if (process.env.NODE_ENV === 'development') {
            console.log('📝 SQL', { text: sqliteQuery, duration: duration + 'ms', rows: rows.length });
          }
          resolve({ rows });
        }
      });
    } else {
      db.run(sqliteQuery, params, function(err) {
        const duration = Date.now() - start;
        if (err) {
          console.error('SQL Hatası:', {
            text: sqliteQuery,
            params,
            message: err.message,
            code: err.code
          });
          reject(err);
        } else {
          if (process.env.NODE_ENV === 'development') {
            console.log('📝 SQL', { text: sqliteQuery, duration: duration + 'ms', changes: this.changes });
          }
          resolve({ rows: [{ id: this.lastID }], rowsAffected: this.changes });
        }
      });
    }
  });
}

// Pool kapama fonksiyonu
function close() {
  return new Promise((resolve) => {
    db.close((err) => {
      if (err) {
        console.error('SQLite kapatma hatası:', err.message);
      } else {
        console.log('SQLite bağlantısı kapatıldı');
      }
      resolve();
    });
  });
}

module.exports = { query, close };