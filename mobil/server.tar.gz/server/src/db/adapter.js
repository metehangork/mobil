const mysql = require('mysql2/promise');

class DatabaseAdapter {
  constructor() {
    this.pool = null;
    this.isMySQL = process.env.DB_HOST && !process.env.PGHOST;
  }

  async init() {
    if (this.isMySQL) {
      this.pool = mysql.createPool({
        host: process.env.DB_HOST || 'localhost',
        user: process.env.DB_USER,
        password: process.env.DB_PASSWORD,
        database: process.env.DB_NAME,
        port: process.env.DB_PORT || 3306,
        waitForConnections: true,
        connectionLimit: 10,
        queueLimit: 0
      });
    } else {
      // Keep PostgreSQL for development
      const { Pool } = require('pg');
      this.pool = new Pool();
    }
  }

  async query(text, params = []) {
    if (!this.pool) await this.init();
    
    if (this.isMySQL) {
      // Convert PostgreSQL queries to MySQL
      const mysqlQuery = text
        .replace(/\$(\d+)/g, '?')  // $1 -> ?
        .replace(/RETURNING \*/g, ''); // Remove RETURNING
      
      const [rows] = await this.pool.execute(mysqlQuery, params);
      return { rows };
    } else {
      return await this.pool.query(text, params);
    }
  }

  async close() {
    if (this.pool) {
      await this.pool.end();
    }
  }
}

const db = new DatabaseAdapter();

module.exports = {
  query: (text, params) => db.query(text, params),
  close: () => db.close()
};