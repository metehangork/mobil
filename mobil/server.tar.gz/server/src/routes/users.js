const express = require('express');
const jwt = require('jsonwebtoken');
const router = express.Router();

// Token doğrulama middleware
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Token gerekli' });
  }

  jwt.verify(token, process.env.JWT_SECRET || 'development_secret', (err, user) => {
    if (err) {
      return res.status(403).json({ error: 'Geçersiz token' });
    }
    req.user = user;
    next();
  });
};

// Mock kullanıcı verileri
let users = [
  {
    id: '1',
    email: 'test@itu.edu.tr',
    name: 'Test Kullanıcı',
    university: 'İstanbul Teknik Üniversitesi',
    department: 'Bilgisayar Mühendisliği',
    classYear: 3,
    isVerified: true,
    courses: ['BIL101', 'MAT201', 'FIZ102'],
    createdAt: new Date()
  },
  {
    id: '2',
    email: 'ahmet@itu.edu.tr',
    name: 'Ahmet Yılmaz',
    university: 'İstanbul Teknik Üniversitesi',
    department: 'Bilgisayar Mühendisliği',
    classYear: 3,
    isVerified: true,
    courses: ['BIL101', 'MAT201', 'FIZ102'],
    createdAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)
  },
  {
    id: '3',
    email: 'ayse@itu.edu.tr',
    name: 'Ayşe Demir',
    university: 'İstanbul Teknik Üniversitesi',
    department: 'Bilgisayar Mühendisliği',
    classYear: 2,
    isVerified: true,
    courses: ['BIL101', 'MAT101', 'FIZ102'],
    createdAt: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000)
  },
  {
    id: '4',
    email: 'mehmet@itu.edu.tr',
    name: 'Mehmet Kaya',
    university: 'İstanbul Teknik Üniversitesi',
    department: 'Elektrik Mühendisliği',
    classYear: 3,
    isVerified: true,
    courses: ['MAT201', 'FIZ102', 'ELK201'],
    createdAt: new Date(Date.now() - 45 * 24 * 60 * 60 * 1000)
  }
];

// Kullanıcı profili getir
router.get('/profile', authenticateToken, (req, res) => {
  const user = users.find(u => u.id === req.user.userId);
  if (!user) {
    return res.status(404).json({ error: 'Kullanıcı bulunamadı' });
  }

  const { password, ...userProfile } = user;
  res.json(userProfile);
});

// Kullanıcı profili güncelle
router.put('/profile', authenticateToken, (req, res) => {
  const userIndex = users.findIndex(u => u.id === req.user.userId);
  if (userIndex === -1) {
    return res.status(404).json({ error: 'Kullanıcı bulunamadı' });
  }

  const { name, department, classYear, courses } = req.body;
  
  users[userIndex] = {
    ...users[userIndex],
    ...(name && { name }),
    ...(department && { department }),
    ...(classYear && { classYear }),
    ...(courses && { courses }),
    updatedAt: new Date()
  };

  const { password, ...updatedUser } = users[userIndex];
  res.json(updatedUser);
});

// Tüm kullanıcıları listele (admin için)
router.get('/', authenticateToken, (req, res) => {
  const currentUser = users.find(u => u.id === req.user.userId);
  if (!currentUser) {
    return res.status(404).json({ error: 'Kullanıcı bulunamadı' });
  }

  // Sadece aynı üniversitedeki kullanıcıları döndür
  const sameUniversityUsers = users
    .filter(u => u.university === currentUser.university && u.id !== currentUser.id)
    .map(({ password, ...user }) => user);

  res.json({
    users: sameUniversityUsers,
    total: sameUniversityUsers.length
  });
});

module.exports = router;