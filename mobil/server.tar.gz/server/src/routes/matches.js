const express = require('express');
const jwt = require('jsonwebtoken');
const router = express.Router();

// Token doğrulama middleware
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Token gerekli' });
  }

  jwt.verify(token, process.env.JWT_SECRET || 'development_secret', (err, user) => {
    if (err) {
      return res.status(403).json({ error: 'Geçersiz token' });
    }
    req.user = user;
    next();
  });
};

// Mock kullanıcı verileri (users.js ile aynı)
const users = [
  {
    id: '1',
    email: 'test@itu.edu.tr',
    name: 'Test Kullanıcı',
    university: 'İstanbul Teknik Üniversitesi',
    department: 'Bilgisayar Mühendisliği',
    classYear: 3,
    isVerified: true,
    courses: ['BIL101', 'MAT201', 'FIZ102'],
    createdAt: new Date()
  },
  {
    id: '2',
    email: 'ahmet@itu.edu.tr',
    name: 'Ahmet Yılmaz',
    university: 'İstanbul Teknik Üniversitesi',
    department: 'Bilgisayar Mühendisliği',
    classYear: 3,
    isVerified: true,
    courses: ['BIL101', 'MAT201', 'FIZ102'],
    createdAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)
  },
  {
    id: '3',
    email: 'ayse@itu.edu.tr',
    name: 'Ayşe Demir',
    university: 'İstanbul Teknik Üniversitesi',
    department: 'Bilgisayar Mühendisliği',
    classYear: 2,
    isVerified: true,
    courses: ['BIL101', 'MAT101', 'FIZ102'],
    createdAt: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000)
  },
  {
    id: '4',
    email: 'mehmet@itu.edu.tr',
    name: 'Mehmet Kaya',
    university: 'İstanbul Teknik Üniversitesi',
    department: 'Elektrik Mühendisliği',
    classYear: 3,
    isVerified: true,
    courses: ['MAT201', 'FIZ102', 'ELK201'],
    createdAt: new Date(Date.now() - 45 * 24 * 60 * 60 * 1000)
  }
];

// Mock eşleşme verileri
let matches = [];

// Eşleştirme algoritması
function calculateCompatibilityScore(user1Courses, user2Courses) {
  const commonCourses = user1Courses.filter(course => user2Courses.includes(course));
  const totalUniqueCourses = new Set([...user1Courses, ...user2Courses]).size;
  
  if (totalUniqueCourses === 0) return 0;
  
  // Ortak ders sayısı / toplam benzersiz ders sayısı * 100
  return Math.round((commonCourses.length / totalUniqueCourses) * 100);
}

// Ders arkadaşları bul
router.post('/find', authenticateToken, (req, res) => {
  try {
    const { selectedCourses } = req.body;
    const currentUser = users.find(u => u.id === req.user.userId);
    
    if (!currentUser) {
      return res.status(404).json({ error: 'Kullanıcı bulunamadı' });
    }

    if (!selectedCourses || selectedCourses.length === 0) {
      return res.status(400).json({ error: 'En az bir ders seçmelisiniz' });
    }

    // Aynı üniversitedeki diğer kullanıcıları bul
    const potentialMatches = users.filter(user => 
      user.id !== currentUser.id &&
      user.university === currentUser.university &&
      user.isVerified
    );

    // Eşleştirme hesapla
    const calculatedMatches = potentialMatches.map(user => {
      const commonCourses = selectedCourses.filter(course => user.courses.includes(course));
      const compatibilityScore = calculateCompatibilityScore(selectedCourses, user.courses);
      
      return {
        id: `match_${currentUser.id}_${user.id}`,
        matchedUser: {
          id: user.id,
          name: user.name,
          email: user.email,
          department: user.department,
          classYear: user.classYear,
          isVerified: user.isVerified,
          courses: user.courses,
          createdAt: user.createdAt
        },
        commonCourses,
        compatibilityScore,
        status: 'pending',
        createdAt: new Date()
      };
    })
    .filter(match => match.commonCourses.length > 0) // En az 1 ortak ders olmalı
    .sort((a, b) => b.compatibilityScore - a.compatibilityScore); // Yüksek skordan düşüğe sırala

    res.json({
      matches: calculatedMatches,
      total: calculatedMatches.length,
      message: `${calculatedMatches.length} ders arkadaşı bulundu!`
    });

  } catch (error) {
    console.error('Find matches error:', error);
    res.status(500).json({ error: 'Eşleştirme yapılamadı' });
  }
});

// Eşleşmeleri listele
router.get('/', authenticateToken, (req, res) => {
  try {
    const currentUser = users.find(u => u.id === req.user.userId);
    if (!currentUser) {
      return res.status(404).json({ error: 'Kullanıcı bulunamadı' });
    }

    // Kullanıcının mevcut eşleşmelerini bul
    const userMatches = matches.filter(match => 
      match.userId === currentUser.id
    );

    res.json({
      matches: userMatches,
      total: userMatches.length
    });

  } catch (error) {
    console.error('Get matches error:', error);
    res.status(500).json({ error: 'Eşleşmeler getirilemedi' });
  }
});

// Eşleşmeyi kabul et
router.post('/:matchId/accept', authenticateToken, (req, res) => {
  try {
    const { matchId } = req.params;
    const matchIndex = matches.findIndex(m => m.id === matchId);
    
    if (matchIndex === -1) {
      return res.status(404).json({ error: 'Eşleşme bulunamadı' });
    }

    matches[matchIndex].status = 'accepted';
    matches[matchIndex].acceptedAt = new Date();

    res.json({
      message: 'Eşleşme kabul edildi!',
      match: matches[matchIndex]
    });

  } catch (error) {
    console.error('Accept match error:', error);
    res.status(500).json({ error: 'Eşleşme kabul edilemedi' });
  }
});

// Eşleşmeyi reddet
router.post('/:matchId/decline', authenticateToken, (req, res) => {
  try {
    const { matchId } = req.params;
    const matchIndex = matches.findIndex(m => m.id === matchId);
    
    if (matchIndex === -1) {
      return res.status(404).json({ error: 'Eşleşme bulunamadı' });
    }

    matches[matchIndex].status = 'declined';
    matches[matchIndex].declinedAt = new Date();

    res.json({
      message: 'Eşleşme reddedildi',
      match: matches[matchIndex]
    });

  } catch (error) {
    console.error('Decline match error:', error);
    res.status(500).json({ error: 'Eşleşme reddedilemedi' });
  }
});

// Uyumluluk skoru hesapla (test endpoint)
router.post('/calculate-score', authenticateToken, (req, res) => {
  try {
    const { courses1, courses2 } = req.body;
    
    if (!courses1 || !courses2) {
      return res.status(400).json({ error: 'İki ders listesi gerekli' });
    }

    const score = calculateCompatibilityScore(courses1, courses2);
    const commonCourses = courses1.filter(course => courses2.includes(course));

    res.json({
      compatibilityScore: score,
      commonCourses,
      totalCourses1: courses1.length,
      totalCourses2: courses2.length,
      algorithm: 'commonCourses / totalUniqueCourses * 100'
    });

  } catch (error) {
    console.error('Calculate score error:', error);
    res.status(500).json({ error: 'Skor hesaplanamadı' });
  }
});

module.exports = router;