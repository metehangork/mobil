const express = require('express');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const { body, validationResult } = require('express-validator');
const { query } = require('../db/pool');
const router = express.Router();

// Geçici memory verification (ileride Redis)
const verificationStore = new Map();

// Debug için store durumunu kontrol
function debugStore() {
  console.log('📋 Store içeriği:', Array.from(verificationStore.entries()));
}

async function findUserByEmail(email) {
  const result = await query('SELECT * FROM users WHERE email = $1 LIMIT 1', [email]);
  return result.rows[0];
}

async function createUser(email) {
  const university = email.split('@')[1] || '';
  const result = await query(
    `INSERT INTO users (email, password_hash, first_name, last_name, is_verified)
     VALUES ($1, '', '', '', true)
     ON CONFLICT (email) DO UPDATE SET updated_at = NOW()
     RETURNING *`,
    [email]
  );
  return result.rows[0];
}

// E-posta doğrulama isteği (basit sistem - hep 123456)
router.post('/request-verification', [
  body('email').isEmail().withMessage('Geçerli e-posta'),
  body('email').custom(v => v.includes('.edu')).withMessage('Üniversite e-postası kullanın')
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }
  const { email } = req.body;
  const code = '123456'; // Sabit kod
  verificationStore.set(email, { code, expiresAt: Date.now() + 60 * 60 * 1000 }); // 1 saat
  console.log(`📧 Doğrulama kodu (${email}): ${code}`);
  res.json({ message: 'Kod gönderildi', email, code });
});

// Kod doğrulama
router.post('/verify-code', [
  body('email').isEmail(),
  body('code').isLength({ min: 6, max: 6 })
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }
  const { email, code } = req.body;
  console.log(`🔍 Kod doğrulama: email=${email}, code=${code}`);
  debugStore();
  const record = verificationStore.get(email);
  if (!record) {
    console.log(`❌ Kod bulunamadı: ${email}`);
    return res.status(400).json({ error: 'Kod bulunamadı' });
  }
  if (record.expiresAt < Date.now()) {
    verificationStore.delete(email);
    return res.status(400).json({ error: 'Kod süresi doldu' });
  }
  if (record.code !== code) return res.status(400).json({ error: 'Geçersiz kod' });

  // Debug için kodu silme, tekrar kullanılabilir olsun
  console.log('✅ Kod doğru, mock user ile devam');

  // DB yok ise mock user döndür
  let user;
  try {
    user = await findUserByEmail(email);
    if (!user) {
      user = await createUser(email);
    }
  } catch (dbError) {
    console.log('⚠️ DB unavailable, using mock user');
    user = {
      id: 'mock_' + Date.now(),
      email: email,
      first_name: email.split('@')[0],
      last_name: '',
      is_verified: true
    };
  }

  const token = jwt.sign(
    { userId: user.id, email: user.email },
    process.env.JWT_SECRET || 'development_secret',
    { expiresIn: '7d' }
  );

  res.json({
    message: 'Giriş başarılı',
    token,
    user: {
      id: user.id,
      email: user.email,
      firstName: user.first_name,
      lastName: user.last_name,
      isVerified: user.is_verified
    }
  });
});

// Token doğrulama middleware
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'Token gerekli' });
  jwt.verify(token, process.env.JWT_SECRET || 'development_secret', (err, user) => {
    if (err) return res.status(403).json({ error: 'Geçersiz token' });
    req.user = user;
    next();
  });
};

router.get('/me', authenticateToken, async (req, res) => {
  const user = await query('SELECT id, email, first_name, last_name, is_verified FROM users WHERE id = $1', [req.user.userId]);
  if (!user.rows[0]) return res.status(404).json({ error: 'Kullanıcı yok' });
  const u = user.rows[0];
  res.json({ id: u.id, email: u.email, firstName: u.first_name, lastName: u.last_name, isVerified: u.is_verified });
});

module.exports = router;