const express = require('express');
const router = express.Router();

// Mock ders verileri
const courses = [
  {
    id: '1',
    code: 'BIL101',
    name: 'Bilgisayar Programlama I',
    department: 'Bilgisayar Mühendisliği',
    credits: 4,
    professor: 'Prof. Dr. Ali Vural',
    university: 'İstanbul Teknik Üniversitesi'
  },
  {
    id: '2',
    code: 'MAT201',
    name: 'Matematik II',
    department: 'Matematik',
    credits: 3,
    professor: 'Doç. Dr. Ayşe Kaya',
    university: 'İstanbul Teknik Üniversitesi'
  },
  {
    id: '3',
    code: 'FIZ102',
    name: 'Fizik II',
    department: 'Fizik',
    credits: 3,
    professor: 'Dr. Mehmet Çelik',
    university: 'İstanbul Teknik Üniversitesi'
  },
  {
    id: '4',
    code: 'ELK201',
    name: 'Elektrik Devreleri',
    department: 'Elektrik Mühendisliği',
    credits: 4,
    professor: 'Prof. Dr. Fatma Öz',
    university: 'İstanbul Teknik Üniversitesi'
  },
  {
    id: '5',
    code: 'BIL201',
    name: 'Veri Yapıları',
    department: 'Bilgisayar Mühendisliği',
    credits: 4,
    professor: 'Doç. Dr. Can Yılmaz',
    university: 'İstanbul Teknik Üniversitesi'
  },
  {
    id: '6',
    code: 'MAT101',
    name: 'Matematik I',
    department: 'Matematik',
    credits: 3,
    professor: 'Dr. Zeynep Arslan',
    university: 'İstanbul Teknik Üniversitesi'
  }
];

// Tüm dersleri getir
router.get('/', (req, res) => {
  const { university, department } = req.query;
  
  let filteredCourses = courses;
  
  if (university) {
    filteredCourses = filteredCourses.filter(course => 
      course.university.toLowerCase().includes(university.toLowerCase())
    );
  }
  
  if (department) {
    filteredCourses = filteredCourses.filter(course => 
      course.department.toLowerCase().includes(department.toLowerCase())
    );
  }
  
  res.json({
    courses: filteredCourses,
    total: filteredCourses.length
  });
});

// Belirli bir dersi getir
router.get('/:courseId', (req, res) => {
  const course = courses.find(c => c.id === req.params.courseId);
  
  if (!course) {
    return res.status(404).json({ error: 'Ders bulunamadı' });
  }
  
  res.json(course);
});

// Ders arama
router.get('/search/:query', (req, res) => {
  const { query } = req.params;
  const searchTerm = query.toLowerCase();
  
  const matchingCourses = courses.filter(course =>
    course.code.toLowerCase().includes(searchTerm) ||
    course.name.toLowerCase().includes(searchTerm) ||
    course.department.toLowerCase().includes(searchTerm)
  );
  
  res.json({
    courses: matchingCourses,
    total: matchingCourses.length,
    query: query
  });
});

module.exports = router;