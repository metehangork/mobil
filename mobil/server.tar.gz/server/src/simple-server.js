const express = require('express');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors({
  origin: ['http://localhost:8080', 'http://localhost:3000', 'http://localhost:3001'],
  credentials: true
}));

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Health check
app.get('/health', (req, res) => {
  res.json({
    status: 'OK',
    timestamp: new Date().toISOString(),
    service: 'UniCampus API',
    version: '1.0.0'
  });
});

// Basic auth routes for testing
app.post('/api/auth/register', (req, res) => {
  const { email, password, firstName, lastName } = req.body;
  
  setTimeout(() => {
    res.json({
      message: 'Kayıt başarılı! E-posta doğrulama kodu gönderildi.',
      email: email
    });
  }, 1000);
});

app.post('/api/auth/verify', (req, res) => {
  const { email, code } = req.body;
  
  setTimeout(() => {
    res.json({
      message: 'E-posta başarıyla doğrulandı!',
      verified: true
    });
  }, 500);
});

// 404 handler
app.use('*', (req, res) => {
  res.status(404).json({
    error: 'Endpoint bulunamadı',
    path: req.originalUrl
  });
});

// Error handler
app.use((err, req, res, next) => {
  console.error('Error:', err);
  res.status(err.status || 500).json({
    error: err.message || 'Sunucu hatası'
  });
});

app.listen(PORT, () => {
  console.log(`🚀 UniCampus API sunucusu http://localhost:${PORT} adresinde çalışıyor`);
  console.log(`📚 Ders arkadaşı eşleştirme sistemi hazır!`);
});