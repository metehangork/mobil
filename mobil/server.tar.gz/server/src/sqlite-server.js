require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(helmet());
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100 // limit each IP to 100 requests per windowMs
});
app.use('/api', limiter);

// SQLite Database
const dbPath = path.join(__dirname, '../database/unicampus.db');
const db = new sqlite3.Database(dbPath);

// Initialize database tables
db.serialize(() => {
  // Users table
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    first_name TEXT NOT NULL,
    last_name TEXT NOT NULL,
    school_id INTEGER,
    department_id INTEGER,
    student_number TEXT,
    phone TEXT,
    birth_date TEXT,
    gender TEXT,
    bio TEXT,
    profile_image_url TEXT,
    is_verified BOOLEAN DEFAULT 0,
    verification_token TEXT,
    is_active BOOLEAN DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  // Schools table
  db.run(`CREATE TABLE IF NOT EXISTS schools (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    city TEXT NOT NULL,
    type TEXT DEFAULT 'university',
    is_active BOOLEAN DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  // Departments table
  db.run(`CREATE TABLE IF NOT EXISTS departments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    school_id INTEGER,
    name TEXT NOT NULL,
    faculty TEXT,
    is_active BOOLEAN DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (school_id) REFERENCES schools (id)
  )`);

  // Matches table
  db.run(`CREATE TABLE IF NOT EXISTS matches (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user1_id INTEGER,
    user2_id INTEGER,
    match_type TEXT DEFAULT 'school_based',
    match_score REAL DEFAULT 0.00,
    status TEXT DEFAULT 'pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user1_id) REFERENCES users (id),
    FOREIGN KEY (user2_id) REFERENCES users (id)
  )`);

  // Insert sample schools
  db.run(`INSERT OR IGNORE INTO schools (id, name, city) VALUES 
    (1, 'İstanbul Teknik Üniversitesi', 'İstanbul'),
    (2, 'Boğaziçi Üniversitesi', 'İstanbul'),
    (3, 'Orta Doğu Teknik Üniversitesi', 'Ankara'),
    (4, 'Ankara Üniversitesi', 'Ankara'),
    (5, 'İzmir Yüksek Teknoloji Enstitüsü', 'İzmir')`);

  // Insert sample departments
  db.run(`INSERT OR IGNORE INTO departments (id, school_id, name, faculty) VALUES 
    (1, 1, 'Bilgisayar Mühendisliği', 'Bilgisayar ve Bilişim Fakültesi'),
    (2, 1, 'Elektrik Mühendisliği', 'Elektrik-Elektronik Fakültesi'),
    (3, 2, 'Bilgisayar Mühendisliği', 'Mühendislik Fakültesi'),
    (4, 2, 'Endüstri Mühendisliği', 'Mühendislik Fakültesi'),
    (5, 3, 'Bilgisayar Mühendisliği', 'Mühendislik Fakültesi')`);
});

console.log('✅ SQLite Database initialized successfully!');

// Routes
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'OK', 
    message: 'UniCampus API Server is running!',
    timestamp: new Date().toISOString()
  });
});

// Get all schools
app.get('/api/schools', (req, res) => {
  db.all('SELECT * FROM schools WHERE is_active = 1 ORDER BY name', (err, rows) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json({ success: true, data: rows });
  });
});

// Get departments by school
app.get('/api/schools/:schoolId/departments', (req, res) => {
  const { schoolId } = req.params;
  db.all(
    'SELECT * FROM departments WHERE school_id = ? AND is_active = 1 ORDER BY name',
    [schoolId],
    (err, rows) => {
      if (err) {
        return res.status(500).json({ error: err.message });
      }
      res.json({ success: true, data: rows });
    }
  );
});

// Basic user registration (simplified)
app.post('/api/auth/register', (req, res) => {
  const { email, password, firstName, lastName, schoolId, departmentId } = req.body;
  
  if (!email || !password || !firstName || !lastName) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  // Simple hash (in production use bcrypt)
  const passwordHash = require('crypto').createHash('sha256').update(password).digest('hex');

  db.run(
    `INSERT INTO users (email, password_hash, first_name, last_name, school_id, department_id) 
     VALUES (?, ?, ?, ?, ?, ?)`,
    [email, passwordHash, firstName, lastName, schoolId, departmentId],
    function(err) {
      if (err) {
        if (err.message.includes('UNIQUE')) {
          return res.status(400).json({ error: 'Email already exists' });
        }
        return res.status(500).json({ error: err.message });
      }
      
      res.status(201).json({ 
        success: true, 
        message: 'User registered successfully',
        userId: this.lastID
      });
    }
  );
});

// Basic login
app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  
  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password required' });
  }

  const passwordHash = require('crypto').createHash('sha256').update(password).digest('hex');

  db.get(
    'SELECT * FROM users WHERE email = ? AND password_hash = ?',
    [email, passwordHash],
    (err, row) => {
      if (err) {
        return res.status(500).json({ error: err.message });
      }
      
      if (!row) {
        return res.status(401).json({ error: 'Invalid credentials' });
      }

      res.json({ 
        success: true, 
        message: 'Login successful',
        user: {
          id: row.id,
          email: row.email,
          firstName: row.first_name,
          lastName: row.last_name,
          schoolId: row.school_id,
          departmentId: row.department_id
        }
      });
    }
  );
});

// Find potential matches
app.get('/api/matches/:userId', (req, res) => {
  const { userId } = req.params;
  
  db.get('SELECT school_id, department_id FROM users WHERE id = ?', [userId], (err, currentUser) => {
    if (err || !currentUser) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Find users from same school/department (excluding current user)
    db.all(`
      SELECT u.id, u.first_name, u.last_name, u.bio, 
             s.name as school_name, d.name as department_name
      FROM users u
      LEFT JOIN schools s ON u.school_id = s.id
      LEFT JOIN departments d ON u.department_id = d.id
      WHERE u.school_id = ? AND u.department_id = ? AND u.id != ? AND u.is_active = 1
      LIMIT 10
    `, [currentUser.school_id, currentUser.department_id, userId], (err, matches) => {
      if (err) {
        return res.status(500).json({ error: err.message });
      }
      
      res.json({ success: true, data: matches });
    });
  });
});

// Error handling
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Something went wrong!' });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: 'Endpoint not found' });
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 UniCampus API Server running on http://localhost:${PORT}`);
  console.log(`📊 Health check: http://localhost:${PORT}/api/health`);
  console.log(`🏫 Schools API: http://localhost:${PORT}/api/schools`);
});

module.exports = app;