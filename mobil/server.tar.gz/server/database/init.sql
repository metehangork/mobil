-- UniCampus Veritabanı İlk Kurulum
-- PostgreSQL için SQL script

-- Veritabanı oluştur (manuel olarak çalıştırılacak)
-- CREATE DATABASE unicampus;

-- Tablolar
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    school_id INTEGER,
    department_id INTEGER,
    student_number VARCHAR(50),
    phone VARCHAR(20),
    birth_date DATE,
    gender VARCHAR(10),
    bio TEXT,
    profile_image_url VARCHAR(500),
    is_verified BOOLEAN DEFAULT false,
    verification_token VARCHAR(255),
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS schools (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    city VARCHAR(100) NOT NULL,
    type VARCHAR(50) DEFAULT 'university', -- university, college, etc.
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS departments (
    id SERIAL PRIMARY KEY,
    school_id INTEGER REFERENCES schools(id),
    name VARCHAR(255) NOT NULL,
    faculty VARCHAR(255),
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS courses (
    id SERIAL PRIMARY KEY,
    department_id INTEGER REFERENCES departments(id),
    code VARCHAR(20) NOT NULL,
    name VARCHAR(255) NOT NULL,
    semester INTEGER,
    credits INTEGER,
    is_active BOOLEAN DEFAULT false, -- başlangıçta pasif
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS matches (
    id SERIAL PRIMARY KEY,
    user1_id INTEGER REFERENCES users(id),
    user2_id INTEGER REFERENCES users(id),
    match_type VARCHAR(50) DEFAULT 'school_based', -- school_based, course_based
    match_score DECIMAL(3,2) DEFAULT 0.00,
    status VARCHAR(20) DEFAULT 'pending', -- pending, accepted, rejected
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user1_id, user2_id)
);

CREATE TABLE IF NOT EXISTS conversations (
    id SERIAL PRIMARY KEY,
    match_id INTEGER REFERENCES matches(id),
    last_message_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS messages (
    id SERIAL PRIMARY KEY,
    conversation_id INTEGER REFERENCES conversations(id),
    sender_id INTEGER REFERENCES users(id),
    message_text TEXT NOT NULL,
    message_type VARCHAR(20) DEFAULT 'text', -- text, image, file
    is_read BOOLEAN DEFAULT false,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS notifications (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    type VARCHAR(50) DEFAULT 'info', -- info, match, message, system
    is_read BOOLEAN DEFAULT false,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- İndeksler
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_school ON users(school_id);
CREATE INDEX IF NOT EXISTS idx_matches_users ON matches(user1_id, user2_id);
CREATE INDEX IF NOT EXISTS idx_messages_conversation ON messages(conversation_id);
CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id);

-- Başlangıç verileri
INSERT INTO schools (name, city) VALUES 
('İstanbul Teknik Üniversitesi', 'İstanbul'),
('Boğaziçi Üniversitesi', 'İstanbul'),
('Orta Doğu Teknik Üniversitesi', 'Ankara'),
('Ankara Üniversitesi', 'Ankara'),
('İzmir Yüksek Teknoloji Enstitüsü', 'İzmir')
ON CONFLICT DO NOTHING;

INSERT INTO departments (school_id, name, faculty) VALUES 
(1, 'Bilgisayar Mühendisliği', 'Bilgisayar ve Bilişim Fakültesi'),
(1, 'Elektrik Mühendisliği', 'Elektrik-Elektronik Fakültesi'),
(2, 'Bilgisayar Mühendisliği', 'Mühendislik Fakültesi'),
(2, 'Endüstri Mühendisliği', 'Mühendislik Fakültesi'),
(3, 'Bilgisayar Mühendisliği', 'Mühendislik Fakültesi'),
(3, 'Makine Mühendisliği', 'Mühendislik Fakültesi')
ON CONFLICT DO NOTHING;